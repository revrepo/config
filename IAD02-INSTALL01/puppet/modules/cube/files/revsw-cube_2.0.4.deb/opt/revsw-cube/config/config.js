module.exports = {
	logging: {
		is_debug_mode_on: false
	}
};
